title: HelloWorld
author: icode4passion
date: 2020-02-23
category: Python , Programming


### Python HelloWorld !!!!!!
     
    # Python Print Hello World

    print("Hello World !!")
     
    
    