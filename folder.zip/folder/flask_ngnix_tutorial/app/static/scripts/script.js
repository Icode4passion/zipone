

function speak(obj) {
    $(obj).articulate('speak');
  };
  
  function pause() {
    $().articulate('pause');
  };
  
  function resume() {
    $().articulate('resume');
  };
  
  function stop() {
    $().articulate('stop');
  };
  
  